WINGS WEBSITE — REAL CLOTHING IMAGES

1. Replace the files in your GitHub Pages repo with everything in this folder.
2. Keep index.html and style.css in the repo root.
3. Upload the entire images folder too.
4. The site now uses the generated WINGS clothing images instead of the placeholder CSS shirts.

Images included:
- images/hero.png
- images/hoodie.png
- images/tee-white.png
- images/tee-black.png
- images/hoodie-detail.png

First drop: March 15, 2027
